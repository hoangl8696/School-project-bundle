package com.example.bamboo.graphexample;

import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private RetrieveData retrieveData;
    private URL url;
    private ProgressBar progressBar;
    private GraphView graphView;
    private ArrayList<Date> date;
    private ArrayList<Float> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            url = new URL("http://users.metropolia.fi/~jarkkov/temploki_2016.csv");
            retrieveData = new RetrieveData();
            retrieveData.execute(url);
        } catch (Exception e) {
            Toast.makeText(this, "URL error", Toast.LENGTH_SHORT).show();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        graphView = (GraphView) findViewById(R.id.graph);

        progressBar.setProgress(0);
        progressBar.setMax(50000);

        date = new ArrayList<>();
        data = new ArrayList<>();
    }

    private class RetrieveData extends AsyncTask<URL, Integer, List<String[]>>{
        private URLConnection connection;
        private InputStream reader;
        private List<String[]> result;

        @Override
        protected List<String[]> doInBackground(URL... urls) {
            URL url = urls[0];
            result =  new ArrayList<>();
            int i = 1;
            publishProgress(i);
            try {
                connection = url.openConnection();
                reader = connection.getInputStream();
                Scanner scanner = new Scanner(reader);
                publishProgress(i++);
                while (scanner.hasNextLine()) {
                    result.add(scanner.nextLine().split(";"));
                    publishProgress(i++);
                }
                publishProgress(i++);
            } catch (Exception e) {
                result = null;
            } finally {
                try {
                    if (reader != null) { reader.close(); }
                    if (connection != null) { reader.close(); }
                    publishProgress(i++);
                } catch (Exception e) {

                }
            }
            publishProgress(i++);
            return result;
        }

        @Override
        protected void onPostExecute(List<String[]> strings) {
            super.onPostExecute(strings);
            progressBar.setVisibility(View.GONE);
            graphView.setVisibility(View.VISIBLE);
            DecimalFormat df = new DecimalFormat();
            DecimalFormatSymbols symbols = new DecimalFormatSymbols();
            symbols.setDecimalSeparator(',');
            symbols.setGroupingSeparator('.');
            df.setDecimalFormatSymbols(symbols);

            DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date measurementDate;

            for (int i = 0; i < 52656; i++) {
                try {
                    measurementDate = (Date) format.parse(strings.get(i)[0]);
                    data.add(df.parse(strings.get(i)[1]).floatValue());
                    date.add(measurementDate);

                } catch (Exception e) {

                }
            }
            Log.d("result day", date.get(52654).toString());
            Log.d("result data", data.get(52654).toString());

            DateFormat graphFormat = new SimpleDateFormat("dd.MM");
            graphView.getGridLabelRenderer().setLabelFormatter(new DateAsXAxisLabelFormatter(MainActivity.this, graphFormat));
            graphView.getGridLabelRenderer().setNumHorizontalLabels(5);
            graphView.getGridLabelRenderer().setHumanRounding(false);

            DataPoint[] dataPoints = new DataPoint[364];
            for (int i = 0; i< 364; i++) {
                dataPoints[i] = new DataPoint(date.get(i*144), data.get(i*144));
            }
            LineGraphSeries<DataPoint> series = new LineGraphSeries<>(dataPoints);
            graphView.addSeries(series);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressBar.setProgress(values[0]);
        }
    }
}

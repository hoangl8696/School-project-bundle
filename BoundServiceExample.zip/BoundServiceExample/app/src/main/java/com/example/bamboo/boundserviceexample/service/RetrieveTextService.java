package com.example.bamboo.boundserviceexample.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.bamboo.boundserviceexample.MainActivity;

public class RetrieveTextService extends Service {
    private HTTPClient mClient;
    private Thread mThread;
    private final IBinder mBinder = new LocalBinder();
    private String mResult;

    private Handler TextHandler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    mResult = (String) msg.obj;
                    Log.d("Result", mResult);
                    break;
                default:
                    throw new IllegalArgumentException("No message with id found");
            }
        }
    };

    public String getResult () {
        return mResult;
    }

    @Override
    public void onCreate() {
        mClient = new HTTPClient(TextHandler);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mResult = "";
        mThread = new Thread(mClient);
        mThread.start();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        mThread = null;
    }

    public class LocalBinder extends Binder {
        public RetrieveTextService getInstance() {
            return RetrieveTextService.this;
        }
    }
}

package com.example.bamboo.boundserviceexample.service;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class HTTPClient implements Runnable {
    private Handler mHandler;
    private String mResult;

    public HTTPClient(Handler textHandler) {
        mResult = "";
        mHandler = textHandler;
    }

    @Override
    public void run() {
        try {
            URL url = new URL("http://users.metropolia.fi/~hoangl/colors.txt");
            URLConnection connection = url.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            String container;
            while ((container = reader.readLine()) != null) {
                mResult += container;
            }
            reader.close();

            Message msg = mHandler.obtainMessage();
            Log.d("result", mResult);
            msg.obj = mResult;
            msg.what = 0;
            mHandler.sendMessage(msg);
        } catch (Exception e) {

        }
    }
}

package com.example.bamboo.arexample;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.wikitude.NativeStartupConfiguration;
import com.wikitude.WikitudeSDK;
import com.wikitude.common.camera.CameraSettings;
import com.wikitude.common.rendering.InternalRendering;
import com.wikitude.common.rendering.RenderExtension;
import com.wikitude.common.rendering.RenderSettings;
import com.wikitude.tracker.ImageTarget;
import com.wikitude.tracker.ImageTracker;
import com.wikitude.tracker.ImageTrackerListener;
import com.wikitude.tracker.Target;
import com.wikitude.tracker.TargetCollectionResource;
import com.wikitude.tracker.TargetCollectionResourceLoadingCallback;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends AppCompatActivity implements ImageTrackerListener, InternalRendering {

    private final String WIKITUDE_SDK_KEY = "2JHewrchkabtzl/iA7xUGS1udMVzgZO97sS10HQ2uY5QNS0qxvfU0rnE4t8XvI0tosEHEX7ylLwH0pY4fgXm1iDrMbGEzyjo/Gv92U7pFIDBBy2PDfyvQI7YdH01jxPOx8ctJrG0n3TGkEZlYYMwCwug3GiSh7yR3ZPmkhl1W8ZTYWx0ZWRfX3yqIrUU4uG9xBbj2KlLmeq/Mxf6Un4ll4+mn3cnKFrThOSjVJm38Ba6+qpMYJBFA4oDEGHLbwqBJBL8dpfD1P3QNqIPmDMb7UShw3mquR7OOz748/Xvj0uw5adOrq77NyroKgeBNmfmvfaWp4prkLLowttdTnR403PNcj7UYiWcOOBwZAFrnWvW35VuwgEA49bq4MHiRMausHj9l65ucVlHLbftrXDNP1+X3OaIhfAUx5L6fSbyo4/rLfn6dkBxorRe8UXg/54ICQqQTXIm72yVw/o7rnERAdL0XCM25wsAXV9T6xDkc59OEj1K4RLs4IC91sqTuVIZlL9vt1C9y5ZJkTLrIivwLH0+sFrqOnn+mRn+1TouR7ywL7c4NnhkJj1iQUC+EGpzmTIcM2w+vTm4sxFVAQXyoaZM/F6NgAn+NV/bFFykJrU4n3mUD6d3gm6dyM/LFDbHL0ypbH9ghGsYtPL4wcPOnpbCgoOl9UwkSk4K/m7R5x8=";
    private WikitudeSDK mWikitudeSDK;
    private TargetCollectionResource mTargetCollectionResource;
    private CustomRenderExtension mCustomRenderExtendsion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWikitudeSDK= new WikitudeSDK(this);
        NativeStartupConfiguration config = new NativeStartupConfiguration();
        config.setLicenseKey(WIKITUDE_SDK_KEY);
        config.setCameraPosition(CameraSettings.CameraPosition.BACK);
        config.setCameraResolution(CameraSettings.CameraResolution.AUTO);
        mWikitudeSDK.onCreate(getApplicationContext(), this, config);
        mTargetCollectionResource = mWikitudeSDK.getTrackerManager().createTargetCollectionResource("file:///android_asset/tracker.wtc", new TargetCollectionResourceLoadingCallback() {
            @Override
            public void onError(int i, String s) {
                Log.d("Error", "Check your link");
            }

            @Override
            public void onFinish() {
                mWikitudeSDK.getTrackerManager().createImageTracker(mTargetCollectionResource, MainActivity.this, null);
            }
        });
        setContentView(mWikitudeSDK.setupWikitudeGLSurfaceView());
    }

    @Override
    protected void onResume() {
        super.onResume();
        mWikitudeSDK.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mWikitudeSDK.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mWikitudeSDK.clearCache();
        mWikitudeSDK.onDestroy();
    }

    @Override
    public RenderExtension provideRenderExtension() {
        mCustomRenderExtendsion = new CustomRenderExtension();
        return mCustomRenderExtendsion;
    }

    @Override
    public void onRenderingApiInstanceCreated(RenderSettings.RenderingAPI renderingAPI) {

    }

    @Override
    public void onTargetsLoaded(ImageTracker imageTracker) {

    }

    @Override
    public void onErrorLoadingTargets(ImageTracker imageTracker, int i, String s) {

    }

    @Override
    public void onImageRecognized(ImageTracker imageTracker, ImageTarget imageTarget) {
        Log.d("Cycle: ", "Img regconized");
    }

    @Override
    public void onImageTracked(ImageTracker imageTracker, ImageTarget imageTarget) {
        Log.d("Cycle: ", "Img tracking");
        mCustomRenderExtendsion.setCurrentlyRegconizedTarget(imageTarget);
    }

    @Override
    public void onImageLost(ImageTracker imageTracker, ImageTarget imageTarget) {
        Log.d("Cycle: ", "Img lost");
        mCustomRenderExtendsion.setCurrentlyRegconizedTarget(null);
    }

    @Override
    public void onExtendedTrackingQualityChanged(ImageTracker imageTracker, ImageTarget imageTarget, int i, int i1) {

    }

    public class CustomRenderExtension implements GLSurfaceView.Renderer, RenderExtension {
        private Target mCurrentlyRegconizedTarget = null;
        private final float[] mMVPMatrix = new float[16];
        private Triangle mTriangle;

        public class Triangle {
            private FloatBuffer mVertextBuffer;
            private final int mProgram;
            private int mPositionHandle;
            private int mColorHandle;
            private int mMVPMatrixHandle;
            private final String mVerTextShaderCode =
                    "attribute vec4 vPosition;"
                            + "uniform mat4 uMVPMatrix;"
                            + "void main() {"
                            + "   gl_Position = uMVPMatrix * vPosition;"
                            + "}";

            private final String mFragmentShaderCode =
                    "precision mediump float;"
                            + "uniform vec4 vColor;"
                            + "void main() {"
                            + "    gl_FragColor = vColor;"
                            + "}";

            static final int COORDS_PER_VERTEX = 3;

            float[] mTriangleCoords = {
                    0.0f,  0.622008459f, 0.0f,
                    -0.5f, -0.311004243f, 0.0f,
                    0.5f, -0.311004243f, 0.0f
            };

            float[] mColor = {0.63671875f, 0.76953125f, 0.22265625f, 1.0f};

            private final int vertexCount = mTriangleCoords.length / COORDS_PER_VERTEX;
            private final int vertexStride = COORDS_PER_VERTEX * 4;

            public Triangle() {
                ByteBuffer bb = ByteBuffer.allocateDirect(mTriangleCoords.length * 4);
                bb.order(ByteOrder.nativeOrder());
                mVertextBuffer = bb.asFloatBuffer();
                mVertextBuffer.put(mTriangleCoords);
                mVertextBuffer.position(0);

                int verTexShader = loadShader(GLES20.GL_VERTEX_SHADER, mVerTextShaderCode);
                int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, mFragmentShaderCode);
                mProgram = GLES20.glCreateProgram();
                GLES20.glAttachShader(mProgram, verTexShader);
                GLES20.glAttachShader(mProgram, fragmentShader);
                GLES20.glLinkProgram(mProgram);
            }

            public int loadShader (int type, String shaderCode) {
                int shader = GLES20.glCreateShader(type);
                GLES20.glShaderSource(shader, shaderCode);
                GLES20.glCompileShader(shader);
                return shader;
            }

            public void draw(float[] mvpMatrix) {
                GLES20.glUseProgram(mProgram);

                mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
                GLES20.glEnableVertexAttribArray(mPositionHandle);
                GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, mVertextBuffer);

                mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
                mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
                GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
                GLES20.glUniform4fv(mColorHandle, 1, mColor, 0);
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0 , vertexCount);
                GLES20.glDisableVertexAttribArray(mPositionHandle);
            }
        }

        @Override
        public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
            mTriangle = new Triangle();
        }

        @Override
        public void onSurfaceChanged(GL10 gl10, int i, int i1) {

        }

        @Override
        public void onPause() {

        }

        @Override
        public void onResume() {

        }

        @Override
        public void useSeparatedRenderAndLogicUpdates() {

        }

        @Override
        public void onUpdate() {

        }

        @Override
        public void onDrawFrame(GL10 gl10) {
            if (mCurrentlyRegconizedTarget != null) {
                Matrix.multiplyMM(mMVPMatrix, 0 , mCurrentlyRegconizedTarget.getProjectionMatrix(), 0, mCurrentlyRegconizedTarget.getViewMatrix(),0);
                mTriangle.draw(mMVPMatrix);
            } else {
                Log.d("Cycle", "Img not regconized");
            }
        }

        public void setCurrentlyRegconizedTarget (final ImageTarget currentlyRegconizedTarget) {
            mCurrentlyRegconizedTarget = currentlyRegconizedTarget;
        }
    }
}

package com.example.bamboo.sqlexaxmple;


import android.app.ListActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SimpleCursorAdapter;
import android.os.Bundle;

import com.example.bamboo.sqlexaxmple.data.Contract;

public class MainActivity extends ListActivity implements android.app.LoaderManager.LoaderCallbacks<Cursor> {

    private SimpleCursorAdapter adapter;
    private void setUpData(){
//        ContentValues values = new ContentValues();
//        values.put(Contract.President.COLUMN_NAME, "Kallio, Kyosti");
//        values.put(Contract.President.COLUMN_YEAR, "1937-1940");
//        values.put(Contract.President.COLUMN_EXTRA, "Nightwing");
//        getContentResolver().insert(Contract.URI, values);
//
//        ContentValues values1 = new ContentValues();
//        values1.put(Contract.President.COLUMN_NAME, "Ryti, Risto Heikki");
//        values1.put(Contract.President.COLUMN_YEAR, "1940-1944");
//        values1.put(Contract.President.COLUMN_EXTRA, "Hummingbird");
//        getContentResolver().insert(Contract.URI, values1);
//
//        ContentValues values2 = new ContentValues();
//        values2.put(Contract.President.COLUMN_NAME, "Mannerheim, Carl Gustav Emil");
//        values2.put(Contract.President.COLUMN_YEAR, "1944-1946");
//        values2.put(Contract.President.COLUMN_EXTRA, "Hornbill");
//        getContentResolver().insert(Contract.URI, values2);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpData();

        String[] from = new String[] {Contract.President.COLUMN_NAME, Contract.President.COLUMN_YEAR};
        int[] to = new int[] {android.R.id.text1, android.R.id.text2};
        adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, null, from, to, 0);
        setListAdapter(adapter);
        getLoaderManager().initLoader(0, null, this);
    }

    @Override
    public android.content.Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] columns = new String[] {Contract.President.COLUMN_ID, Contract.President.COLUMN_NAME, Contract.President.COLUMN_YEAR};
        return new android.content.CursorLoader(this, Contract.URI, columns,null,null,null);
    }

    @Override
    public void onLoadFinished(android.content.Loader<Cursor> loader, Cursor cursor) {
        adapter.swapCursor(cursor);
    }

    @Override
    public void onLoaderReset(android.content.Loader<Cursor> loader) {
        adapter.swapCursor(null);
    }
}

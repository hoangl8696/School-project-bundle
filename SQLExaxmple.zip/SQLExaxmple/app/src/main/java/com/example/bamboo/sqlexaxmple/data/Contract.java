package com.example.bamboo.sqlexaxmple.data;

import android.content.UriMatcher;
import android.net.Uri;
import android.provider.BaseColumns;

import java.net.URI;

public final class Contract implements BaseColumns {

    private static final String CONTENT_AUTHORITY = "com.example.bamboo.sqlexaxmple.data.PresidentProvider";
    private static final String URL = "content://" + CONTENT_AUTHORITY + "/pprovider";
    public static final Uri URI = Uri.parse(URL);
    public static final int uriCode = 1;
    public static final UriMatcher uriMatcher;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(CONTENT_AUTHORITY, "pprovider", uriCode);
    }

    private Contract (){}
    public static final class President {
        public static final String TABLE_NAME = "President";
        public static final String COLUMN_ID = BaseColumns._ID;
        public static final String COLUMN_NAME = "Name";
        public static final String COLUMN_YEAR = "Year";
        public static final String COLUMN_EXTRA = "Extra";
    }
}

package com.example.bamboo.sqlexaxmple.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

import java.util.HashMap;

public class PresidentProvider extends ContentProvider {
    private static HashMap<String, String> values;
    private SQLiteDatabase db;
    private SQLHelper helper;

    private static class SQLHelper extends SQLiteOpenHelper {
        private static final int DATABASE_VERSION = 1;
        private static final String DATABASE_NAME = "MyDatabase";
        private static final String CREATE_TABLE =
                "CREATE TABLE IF NOT EXISTS " + Contract.President.TABLE_NAME + " ("
                        + Contract.President.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + Contract.President.COLUMN_NAME + " TEXT, "
                        + Contract.President.COLUMN_YEAR + " TEXT, "
                        + Contract.President.COLUMN_EXTRA + " TEXT)";
        private static final String UPGRADE_TABLE = "DROP TABLE IF EXISTS " + Contract.President.TABLE_NAME;

        public SQLHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL(UPGRADE_TABLE);
            onCreate(sqLiteDatabase);
        }
    }

    public PresidentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int rowsDeleted;
        switch (Contract.uriMatcher.match(uri)){
            case Contract.uriCode:
                rowsDeleted = db.delete(Contract.President.TABLE_NAME,selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsDeleted;
    }

    @Override
    public String getType(Uri uri) {
        switch (Contract.uriMatcher.match(uri)){
            case Contract.uriCode:
                return "vnd.android.cursor.dir/pprovider";
            default:
                throw new IllegalArgumentException("Unsupported URI");
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        long id = db.insert(Contract.President.TABLE_NAME, null, values);
        if (id  != -1){
            Uri _uri = ContentUris.withAppendedId(uri, id);
            getContext().getContentResolver().notifyChange(_uri, null);
            return _uri;
        } else {
            return null;
        }
    }

    @Override
    public boolean onCreate() {
        helper = new SQLHelper(getContext());
        db = helper.getWritableDatabase();
        if (db != null) {
            return true;
        }
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        queryBuilder.setTables(Contract.President.TABLE_NAME);
        switch (Contract.uriMatcher.match(uri)){
            case Contract.uriCode:
                queryBuilder.setProjectionMap(values);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }
        Cursor cursor = queryBuilder.query(db, projection, selection, selectionArgs, null, null, sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        int rowsUpdated;
        switch (Contract.uriMatcher.match(uri)){
            case Contract.uriCode:
                rowsUpdated = db.update(Contract.President.TABLE_NAME, values,selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsUpdated;
    }
}

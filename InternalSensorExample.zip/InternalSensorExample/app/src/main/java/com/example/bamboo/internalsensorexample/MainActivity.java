package com.example.bamboo.internalsensorexample;

import android.content.Context;
import android.content.res.Resources;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
* This example use 2 type of sensors:
 * - Linear acceleration sensor: detect acceleration in 3 axis, is used to detect shake gesture in this example
 * - Game rotation vector sensor: return raw data to construct a rotation matrix, is used to identify phone's rotation
 * More info on these sensors can be found:
 * https://developer.android.com/guide/topics/sensors/sensors_position.html
 * https://developer.android.com/guide/topics/sensors/sensors_motion.html
 * */

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    //Sensors references
    private SensorManager mSensorManager;
    private List<Sensor> mSensorsList;
    private Sensor mLinearAccelerationSensor, mGameRotationVectorSensor;
    private Vibrator mVibrator;

    //UI references
    private TextView x,y,z,shakeTime, x2,y2,z2;
    private Button btn;
    private ImageButton imgBtn;

    //Linear acceleration sensor always have an offset that need to calibrate
    private Float mOffsetX, mOffsetY, mOffsetZ;
    private boolean mIsCalibrated;

    //Shake configuration, intensity will determine how hard you have to move that it register as a shake
    //Time will determine how many time it register a shake until something happen (a vibrate and a toaste)
    private static final Double SHAKE_SENSITIVITY_INTENSITY = 25.00;
    private static final int SHAKE_SENSITIVITY_TIME = 3;

    //Current number of shake
    private int mCurrentTime;

    //Current possition of the android icon (the object we use in this example to interact with the phone's rotation)
    private double mCurrentX;
    private double mCurrentY;

    //Rotation matrix can be built from data of the Game rotation vector sensor, orientation angles can be built from
    //the rotation matrix
    private final float[] mRotationMatrix = new float[9];
    private final float[] mOrientationAngles = new float[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Set up sensors
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensorsList = mSensorManager.getSensorList(Sensor.TYPE_ALL);
        mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        for (Sensor sensor : mSensorsList) {
            Log.d("Sensors: ", sensor.getName());
        }
        //TODO: normally check if sensor exist on the phone (not null)
        mLinearAccelerationSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        mGameRotationVectorSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);

        //Set up UI
        x = (TextView) findViewById(R.id.x);
        y = (TextView) findViewById(R.id.y);
        z = (TextView) findViewById(R.id.z);
        x2 = (TextView) findViewById(R.id.x_2);
        y2 = (TextView) findViewById(R.id.y_2);
        z2 = (TextView) findViewById(R.id.z_2);
        btn = (Button) findViewById(R.id.calibrate);
        imgBtn = (ImageButton) findViewById(R.id.imageButton);
        shakeTime = (TextView) findViewById(R.id.shake_time);

        //Set up helper variables
        mIsCalibrated = false;
        mCurrentTime = 0;
        mCurrentX = imgBtn.getX();
        mCurrentY = imgBtn.getY();

        //Set up calibration button
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mIsCalibrated = true;
                Toast.makeText(MainActivity.this, "Calibration: " + mIsCalibrated, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Register to this listener, in third parameter there are numerous delay options:
        //SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI, SensorManager.SENSOR_DELAY_FASTEST,
        //SensorManager.SENSOR_DELAY_GAME, or we can specify the custom time that the listener will receive data
        mSensorManager.registerListener(this, mLinearAccelerationSensor, SensorManager.SENSOR_DELAY_UI);
        mSensorManager.registerListener(this, mGameRotationVectorSensor, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //Unregistered when app is not on the foreground
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        switch (sensorEvent.sensor.getType()) {
            case Sensor.TYPE_LINEAR_ACCELERATION:
                if (!mIsCalibrated) {
                    //Initial offset that need to be deducted
                    mOffsetX = sensorEvent.values[0];
                    mOffsetY = sensorEvent.values[1];
                    mOffsetZ = sensorEvent.values[2];

                    x.setText(Float.toString(mOffsetX));
                    y.setText(Float.toString(mOffsetY));
                    z.setText(Float.toString(mOffsetZ));
                } else {
                    //Calibrate to return the true value
                    Float realValueX = Math.abs(sensorEvent.values[0] - mOffsetX);
                    Float realValueY = Math.abs(sensorEvent.values[1] - mOffsetY);
                    Float realValueZ = Math.abs(sensorEvent.values[2] - mOffsetZ);

                    x.setText(Float.toString(realValueX));
                    y.setText(Float.toString(realValueY));
                    z.setText(Float.toString(realValueZ));

                    //In this example, we check the acceleration of x axis for the shake gesture
                    //More info on the device's coordinate system:
                    //https://developer.android.com/reference/android/hardware/SensorEvent.html
                    if (realValueX > SHAKE_SENSITIVITY_INTENSITY) {
                        mCurrentTime++;
                        shakeTime.setText(Integer.toString(mCurrentTime));
                        //If the app register the user have shake 3 times, a toast will appear, phone vibrate, and shake
                        //count get reset
                        if (mCurrentTime > SHAKE_SENSITIVITY_TIME) {
                            Toast.makeText(MainActivity.this, "Shake it off!", Toast.LENGTH_SHORT).show();
                            mVibrator.vibrate(500);
                            mCurrentTime = 0;
                            shakeTime.setText(Integer.toString(mCurrentTime));
                        }
                    }
                }
                break;

            case Sensor.TYPE_GAME_ROTATION_VECTOR:
                //Convert data from sensor event (sensorEvent.values) of type float[3] to rotation matrix
                // of type float[9] (rotation matrix of size 3x3), store the result in mRotationMatrix
                SensorManager.getRotationMatrixFromVector(mRotationMatrix, sensorEvent.values);

                //Convert the rotation matrix into readable orientation angles of type float[3] (1 for each axis)
                //the unit is in radian, store the result in mOrientationAngles
                SensorManager.getOrientation(mRotationMatrix, mOrientationAngles);

                //TODO: play with this a bit more, the axis is a bit confusing, not sure which values inside the
                //TODO: mOrientationAngles is which axis, this is just my guessing
                //Out of 3 axis, 2 will remain fixed relative to the plane that is the ground, 1 axis will drift and will
                //remain fixed to whatever the initial setup it point to
                //Z axis max 180 will dift accordingly
                z2.setText(Double.toString(Math.abs(mOrientationAngles[0]*180/Math.PI)));
                //X axis max 90
                x2.setText(Double.toString(mOrientationAngles[1]*180/Math.PI));
                //Y axis max 180
                y2.setText(Double.toString(mOrientationAngles[2]*180/Math.PI));

                //Figure the move increments
                mCurrentX = mCurrentX - mOrientationAngles[1]*180/Math.PI;
                mCurrentY = mCurrentY + mOrientationAngles[2]*180/Math.PI;

                //Prevent the object from moving too far away from the visible screen
                if (mCurrentX < 0) {
                    mCurrentX = 0;
                    mVibrator.vibrate(100);
                }
                if (mCurrentY < 0) {
                    mCurrentY = 0;
                    mVibrator.vibrate(100);
                }
                if (mCurrentX > Resources.getSystem().getDisplayMetrics().heightPixels) {
                    mCurrentX = Resources.getSystem().getDisplayMetrics().heightPixels - 1000;
                    mVibrator.vibrate(100);
                }
                if (mCurrentY > Resources.getSystem().getDisplayMetrics().widthPixels) {
                    mCurrentY = Resources.getSystem().getDisplayMetrics().widthPixels - 100;
                    mVibrator.vibrate(100);
                }

                imgBtn.setY((float) mCurrentX);
                imgBtn.setX((float) mCurrentY);
                break;
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }
}

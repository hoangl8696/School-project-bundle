package com.example.bamboo.listexample;

/**
 * Created by Bamboo on 8/23/2017.
 */

public class PresidentModel {
    private String firstName;
    private String lastName;
    private int from;
    private int to;
    private String extra;

    public PresidentModel (String firstName, String lastName, int from, int to, String extra) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.from = from;
        this.to = to;
        this.extra = extra;
    }

    public String getFirstName(){
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public int getFrom() {
        return this.from;
    }

    public int getTo() {
        return this.to;
    }

    public String getExtra() {
        return this.extra;
    }

    public String toString(){
        return this.firstName+", "+this.lastName+" "+this.from+" - "+this.to+" - "+this.extra;
    }
}

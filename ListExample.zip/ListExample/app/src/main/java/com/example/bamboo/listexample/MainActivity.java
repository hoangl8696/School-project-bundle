package com.example.bamboo.listexample;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListActivity;
import android.content.Context;
import android.net.Uri;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static PresidentModel[] presidentList = {
            new PresidentModel("Stahlberg", "Kaarlo Juho", 1919, 1925, "Coooool!"),
            new PresidentModel("Relander", "Lauri Kristan", 1925, 1931, "Awesome!"),
            new PresidentModel("Svinhufvud", "Pehr Evind", 1931, 1937, "Bleeeh!"),
            new PresidentModel("Kallio", "Kyosti", 1937, 1940, "Meeh!"),
            new PresidentModel("Ryti", "Risto Heikki", 1940, 1944, "Nanananana!"),
            new PresidentModel("Mannerheim", "Carl Gustav Emil", 1944, 1946, "Batman!"),
            new PresidentModel("Paasikivi", "Juho Kusti", 1946, 1956, "Robin!"),
            new PresidentModel("Kekkonen", "Urho Kaleva", 1956, 1982, "Raven!"),
            new PresidentModel("Koivisto", "Mauno Henrik", 1982, 1994, "Nightwing!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Ahtisaari", "Martti Oiva Kalevi", 1994, 2000, "Nightingale!"),
            new PresidentModel("Halonen", "Tarja Kaarina", 2000, 2012, "Mockingbird!")
    };

    private static class ViewHolder {
        TextView fullname;
        TextView from;
        TextView to;
    }

    private TextView detail;
    private TextView extra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView list = (ListView) findViewById(R.id.listView);
        detail = (TextView) findViewById(R.id.textView1);
        extra = (TextView) findViewById(R.id.textView2);
        PresidentAdapter customAdapter = new PresidentAdapter(this, R.layout.list_item, presidentList);
        list.setAdapter(customAdapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                TextView name = (TextView) view.findViewById(R.id.name);
                TextView from = (TextView) view.findViewById(R.id.from);
                TextView to = (TextView) view.findViewById(R.id.to);
                detail.setText(name.getText().toString()+"   "+from.getText().toString()+"-"+to.getText().toString());
                extra.setText(presidentList[i].getExtra());
            }
        });
    }

    private class PresidentAdapter extends ArrayAdapter<PresidentModel> {
        private PresidentAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull PresidentModel[] presidentList) {
            super(context, resource, presidentList);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            View v = convertView;
            if (v == null){
                LayoutInflater inflater = LayoutInflater.from(getContext());
                v = inflater.inflate(R.layout.list_item, null);
            }
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.fullname = (TextView) v.findViewById(R.id.name);
            viewHolder.from = (TextView) v.findViewById(R.id.from);
            viewHolder.to = (TextView) v.findViewById(R.id.to);
            v.setTag(viewHolder);
            PresidentModel currentItem = getItem(position);
            if (currentItem != null) {
                TextView fullname = ((ViewHolder) v.getTag()).fullname;
                TextView from = ((ViewHolder) v.getTag()).from;
                TextView to = ((ViewHolder) v.getTag()).to;

                if (fullname  != null && from != null && to != null) {
                    from.setText(Integer.toString(currentItem.getFrom()));
                    to.setText(Integer.toString(currentItem.getTo()));
                    fullname.setText(currentItem.getFirstName() + ", " + currentItem.getLastName());
                }
            }
            return v;
        }
    }
}

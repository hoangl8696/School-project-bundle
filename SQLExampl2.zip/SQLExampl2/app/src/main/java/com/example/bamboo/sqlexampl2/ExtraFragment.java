package com.example.bamboo.sqlexampl2;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.bamboo.sqlexampl2.model.Contract;
import com.example.bamboo.sqlexampl2.model.Extra;
import com.example.bamboo.sqlexampl2.model.President;

public class ExtraFragment extends android.app.Fragment{

    private EditText extraText;
    private Button insert;
    private Extra extra;

    public ExtraFragment() {
        // Required empty public constructor
    }

    public static ExtraFragment newInstance() {
        ExtraFragment fragment = new ExtraFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_extra, container, false);
        extraText = (EditText) v.findViewById(R.id.extra);
        insert = (Button) v.findViewById(R.id.insert_button);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                extra = new Extra(extraText.getText().toString());
                values.put(Contract.Extra.COLUMN_EXTRA, extra.getExtra());
                getActivity().getContentResolver().insert(Contract.Extra.CONTENT_URI, values);

                extraText.getText().clear();
            }
        });
        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}

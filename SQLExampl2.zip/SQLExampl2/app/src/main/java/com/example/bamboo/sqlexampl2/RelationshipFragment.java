package com.example.bamboo.sqlexampl2;


import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.bamboo.sqlexampl2.model.Contract;

import java.util.ArrayList;

public class RelationshipFragment extends android.app.Fragment implements LoaderManager.LoaderCallbacks<Cursor>{

    private Spinner spinnerPresident;
    private Spinner spinnerExtra;
    private Button insert;
    private SimpleCursorAdapter presidentAdapter;
    private SimpleCursorAdapter extraAdapter;

    private long presidentID;
    private long extraID;

    private String[] fromPresident = new String[] {Contract.President.COLUMN_NAME};
    private int[] to = new int[] {android.R.id.text1};
    private String[] fromExtra = new String[] {Contract.Extra.COLUMN_EXTRA};

    public RelationshipFragment() {
        // Required empty public constructor
    }

    public static RelationshipFragment newInstance() {
        RelationshipFragment fragment = new RelationshipFragment();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_relationship, container, false);
        spinnerPresident = (Spinner) v.findViewById(R.id.spinner);
        spinnerExtra = (Spinner) v.findViewById(R.id.spinner2);
        insert = (Button) v.findViewById(R.id.insert_button);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                values.put(Contract.Relationship.COLUMN_ID_1, presidentID);
                values.put(Contract.Relationship.COLUMN_ID_2, extraID);
                getActivity().getContentResolver().insert(Contract.Relationship.CONTENT_URI, values);
                Toast.makeText(getActivity(), "Sucess", Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        presidentAdapter = new SimpleCursorAdapter(getActivity(), android.R.layout.simple_dropdown_item_1line, null, fromPresident, to, 0);
        extraAdapter = new SimpleCursorAdapter(getActivity(), android.R.layout.simple_dropdown_item_1line, null, fromExtra, to, 0);

        spinnerExtra.setAdapter(extraAdapter);
        spinnerPresident.setAdapter(presidentAdapter);

        spinnerPresident.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                presidentID = adapterView.getItemIdAtPosition(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });

        spinnerExtra.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                extraID = adapterView.getItemIdAtPosition(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        getLoaderManager().initLoader(0, null, this);
        getLoaderManager().initLoader(1, null, this);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        String[] columns;
        switch (i) {
            case 0:
                columns = new String[] {Contract.President.COLUMN_ID, Contract.President.COLUMN_NAME};
                return new CursorLoader(getActivity(), Contract.President.CONTENT_URI, columns, null, null, null);
            case 1:
                columns = new String[] {Contract.Extra.COLUMN_ID, Contract.Extra.COLUMN_EXTRA};
                return new CursorLoader(getActivity(), Contract.Extra.CONTENT_URI, columns, null, null, null);
            default:
                return null;
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        switch (loader.getId()) {
            case 0:
                presidentAdapter.swapCursor(cursor);
                break;
            case 1:
                extraAdapter.swapCursor(cursor);
                break;
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        switch (loader.getId()) {
            case 0:
                presidentAdapter.swapCursor(null);
                break;
            case 1:
                extraAdapter.swapCursor(null);
                break;
        }
    }
}

package com.example.bamboo.sqlexampl2.model;


public class Extra {
    private String extra;

    public Extra (String extra) {
        this.extra = extra;
    }

    public String getExtra () {
        return this.extra;
    }
    public void setExtra (String extra) {
        this.extra = extra;
    }
}

package com.example.bamboo.sqlexampl2;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.bamboo.sqlexampl2.model.Contract;
import com.example.bamboo.sqlexampl2.model.President;

public class PresidentFragment extends android.app.Fragment {

    private EditText presidentName;
    private EditText fromYear;
    private EditText toYear;
    private Button insert;

    private President president;

    public PresidentFragment() {
        // Required empty public constructor
    }

    public static PresidentFragment newInstance() {
        PresidentFragment fragment = new PresidentFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_president, container, false);
        presidentName = (EditText) v.findViewById(R.id.president_name);
        fromYear = (EditText) v.findViewById(R.id.from);
        toYear = (EditText) v.findViewById(R.id.to);
        insert = (Button) v.findViewById(R.id.insert_button);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                president = new President(presidentName.getText().toString(), fromYear.getText().toString(), toYear.getText().toString());
                values.put(Contract.President.COLUMN_NAME, president.getName());
                values.put(Contract.President.COLUMN_YEAR, president.getYear());
                getActivity().getContentResolver().insert(Contract.President.CONTENT_URI, values);

                presidentName.getText().clear();
                toYear.getText().clear();
                fromYear.getText().clear();
            }
        });

        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}

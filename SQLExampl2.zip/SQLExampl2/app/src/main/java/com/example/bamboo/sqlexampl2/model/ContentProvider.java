package com.example.bamboo.sqlexampl2.model;


import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.provider.BaseColumns;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

public class ContentProvider extends android.content.ContentProvider{
    private SQLHelper helper = null;


    @Override
    public boolean onCreate() {
        helper = new SQLHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        SQLiteDatabase db = helper.getReadableDatabase();
        SQLiteQueryBuilder builder = new SQLiteQueryBuilder();
        Cursor cursor;
        switch (Contract.URI_MATCHER.match(uri)) {
            case Contract.PRESIDENT_LIST:
                builder.setTables(Contract.President.TABLE_NAME);
                break;
            case Contract.PRESIDENT_ID:
                builder.setTables(Contract.President.TABLE_NAME);
                builder.appendWhere(Contract.President.TABLE_NAME + "." + BaseColumns._ID + " = " + uri.getLastPathSegment());
                break;
            case Contract.EXTRA_LIST:
                builder.setTables(Contract.Extra.TABLE_NAME);
                break;
            case Contract.EXTRA_ID:
                builder.setTables(Contract.Extra.TABLE_NAME);
                builder.appendWhere(Contract.Extra.TABLE_NAME + "." + BaseColumns._ID + " = " + uri.getLastPathSegment());
                break;
            case Contract.RELATIONSHIP_LIST:
                builder.setTables(Contract.Relationship.TABLE_NAME);
                break;
            case Contract.RELATIONSHIP_ID:
                builder.setTables(Contract.Relationship.TABLE_NAME);
                builder.appendWhere(Contract.Relationship.TABLE_NAME + "." + BaseColumns._ID + " = " + uri.getLastPathSegment());
                break;
            case Contract.JOIN_LIST:
                //cursor = db.rawQuery();
                cursor = null;
                cursor.setNotificationUri(getContext().getContentResolver(), uri);
                return cursor;
            case Contract.JOIN_ID:
                //cursor = db.rawQuery();
                cursor = null;
                cursor.setNotificationUri(getContext().getContentResolver(), uri);
                return cursor;
            default:
                throw new IllegalArgumentException("Unsupported URI " + uri);
        }
        cursor = builder.query(db, projection, selection, selectionArgs, null, null, sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        switch (Contract.URI_MATCHER.match(uri)) {
            case Contract.PRESIDENT_LIST:
                return Contract.President.CONTENT_TYPE;
            case Contract.PRESIDENT_ID:
                return Contract.President.CONTENT_ITEM_TYPE;
            case Contract.EXTRA_LIST:
                return Contract.Extra.CONTENT_TYPE;
            case Contract.EXTRA_ID:
                return Contract.Extra.CONTENT_ITEM_TYPE;
            case Contract.RELATIONSHIP_LIST:
                return Contract.Relationship.CONTENT_TYPE;
            case Contract.RELATIONSHIP_ID:
                return Contract.Relationship.CONTENT_ITEM_TYPE;
            case Contract.JOIN_LIST:
                return ContentResolver.CURSOR_DIR_BASE_TYPE + "join";
            case Contract.JOIN_ID:
                return ContentResolver.CURSOR_ITEM_BASE_TYPE + "join";
            default:
                return null;
        }
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        SQLiteDatabase db = helper.getWritableDatabase();
        long id;
        switch (Contract.URI_MATCHER.match(uri)) {
            case Contract.PRESIDENT_LIST:
                id = db.insert(Contract.President.TABLE_NAME, null, contentValues);
                if (id != -1) {
                    Uri _uri = ContentUris.withAppendedId(uri, id);
                    getContext().getContentResolver().notifyChange(_uri, null);
                    return _uri;
                }
            case Contract.PRESIDENT_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.EXTRA_LIST:
                id = db.insert(Contract.Extra.TABLE_NAME, null, contentValues);
                if (id != -1) {
                    Uri _uri = ContentUris.withAppendedId(uri, id);
                    getContext().getContentResolver().notifyChange(_uri, null);
                    return _uri;
                }
            case Contract.EXTRA_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.RELATIONSHIP_LIST:
                id = db.insert(Contract.Relationship.TABLE_NAME, null, contentValues);
                if (id != -1) {
                    Uri _uri = ContentUris.withAppendedId(uri, id);
                    getContext().getContentResolver().notifyChange(_uri, null);
                    return _uri;
                }
            case Contract.RELATIONSHIP_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.JOIN_LIST:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.JOIN_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            default:
                throw new IllegalArgumentException("Unsupported URI " + uri);
        }
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rowsDelete = 0;
        String where;
        switch (Contract.URI_MATCHER.match(uri)) {
            case Contract.PRESIDENT_LIST:
                rowsDelete = db.delete(Contract.President.TABLE_NAME, selection, selectionArgs);
                break;
            case Contract.PRESIDENT_ID:
                where = Contract.President.TABLE_NAME + "." + Contract.President.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsDelete = db.delete(Contract.President.TABLE_NAME, where, selectionArgs);
                break;
            case Contract.EXTRA_LIST:
                rowsDelete = db.delete(Contract.Extra.TABLE_NAME, selection, selectionArgs);
                break;
            case Contract.EXTRA_ID:
                where = Contract.Extra.TABLE_NAME + "." + Contract.Extra.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsDelete = db.delete(Contract.Extra.TABLE_NAME, where, selectionArgs);
                break;
            case Contract.RELATIONSHIP_LIST:
                rowsDelete = db.delete(Contract.Relationship.TABLE_NAME, selection, selectionArgs);
                break;
            case Contract.RELATIONSHIP_ID:
                where = Contract.Relationship.TABLE_NAME + "." + Contract.Relationship.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsDelete = db.delete(Contract.Relationship.TABLE_NAME, where, selectionArgs);
                break;
            case Contract.JOIN_LIST:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.JOIN_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            default:
                throw new IllegalArgumentException("Unsupported URI " + uri);
        }
        if (rowsDelete > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDelete;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rowsUpdate = 0;
        String where = "";
        switch (Contract.URI_MATCHER.match(uri)) {
            case Contract.PRESIDENT_LIST:
                rowsUpdate = db.update(Contract.President.TABLE_NAME, contentValues, selection, selectionArgs);
                break;
            case Contract.PRESIDENT_ID:
                where = Contract.President.TABLE_NAME + "." + Contract.President.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsUpdate = db.update(Contract.President.TABLE_NAME, contentValues, where, selectionArgs);
                break;
            case Contract.EXTRA_LIST:
                rowsUpdate = db.update(Contract.Extra.TABLE_NAME, contentValues, selection, selectionArgs);
                break;
            case Contract.EXTRA_ID:
                where = Contract.Extra.TABLE_NAME + "." + Contract.Extra.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsUpdate = db.update(Contract.Extra.TABLE_NAME, contentValues, where, selectionArgs);
                break;
            case Contract.RELATIONSHIP_LIST:
                rowsUpdate = db.update(Contract.Relationship.TABLE_NAME, contentValues, selection, selectionArgs);
                break;
            case Contract.RELATIONSHIP_ID:
                where = Contract.Relationship.TABLE_NAME + "." + Contract.Relationship.COLUMN_ID + " = " + uri.getLastPathSegment();
                if (!TextUtils.isEmpty(selection)) {
                    where += " AND " + selection;
                }
                rowsUpdate = db.update(Contract.Relationship.TABLE_NAME, contentValues, where, selectionArgs);
                break;
            case Contract.JOIN_LIST:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            case Contract.JOIN_ID:
                throw new IllegalArgumentException("Unsupported URI " + uri);
            default:
                throw new IllegalArgumentException("Unsupported URI " + uri);
        }
        if (rowsUpdate > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsUpdate;
    }

    private static class SQLHelper extends SQLiteOpenHelper {
        private static final int DATABASE_VERSION = 1;
        private static final String DATABASE_NAME = "MyDataBase";

        private static final String CREATE_TABLE_PRESIDENT =
                "CREATE TABLE IF NOT EXISTS " + Contract.President.TABLE_NAME + " ("
                        + Contract.President.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + Contract.President.COLUMN_NAME + " TEXT, "
                        + Contract.President.COLUMN_YEAR + " TEXT)";

        private static final String CREATE_TABLE_EXTRA =
                "CREATE TABLE IF NOT EXISTS " + Contract.Extra.TABLE_NAME + " ("
                        + Contract.Extra.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + Contract.Extra.COLUMN_EXTRA + " TEXT)";

        private static final String CREATE_TABLE_RELATIONSHIP =
                "CREATE TABLE IF NOT EXISTS " + Contract.Relationship.TABLE_NAME + " ("
                        + Contract.Relationship.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + Contract.Relationship.COLUMN_ID_1 + " INTEGER, "
                        + Contract.Relationship.COLUMN_ID_2 + " INTEGER, "
                        + "FOREIGN KEY (" + Contract.Relationship.COLUMN_ID_1 + ") REFERENCES " + Contract.President.TABLE_NAME + "(" + Contract.President.COLUMN_ID + "), "
                        + "FOREIGN KEY (" + Contract.Relationship.COLUMN_ID_2 + ") REFERENCES " + Contract.Extra.TABLE_NAME + "(" + Contract.Extra.COLUMN_ID + "))";

        private static final String UPGRADE_TABLE_PRESIDENT = "DROP TABLE IF EXISTS " + Contract.President.TABLE_NAME;
        private static final String UPGRADE_TABLE_EXTRA = "DROP TABLE IF EXISTS " + Contract.Extra.TABLE_NAME;
        private static final String UPGRADE_TABLE_RELATIONSHIP = "DROP TABLE IF EXISTS " + Contract.Relationship.TABLE_NAME;

        public SQLHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(CREATE_TABLE_PRESIDENT);
            sqLiteDatabase.execSQL(CREATE_TABLE_EXTRA);
            sqLiteDatabase.execSQL(CREATE_TABLE_RELATIONSHIP);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL(UPGRADE_TABLE_PRESIDENT);
            sqLiteDatabase.execSQL(UPGRADE_TABLE_EXTRA);
            sqLiteDatabase.execSQL(UPGRADE_TABLE_RELATIONSHIP);
            onCreate(sqLiteDatabase);
        }
    }
}

package com.example.bamboo.sqlexampl2;

import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button presidentBtn;
    private Button extraBtn;
    private Button listBtn;
    private Button relationshipBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        presidentBtn = (Button) findViewById(R.id.button_president);
        extraBtn = (Button) findViewById(R.id.button_extra);
        listBtn = (Button) findViewById(R.id.button_list);
        relationshipBtn = (Button) findViewById(R.id.button_relationship);

        presidentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft =  getFragmentManager().beginTransaction();
                ft.replace(R.id.container, PresidentFragment.newInstance());
                ft.commit();
            }
        });

        extraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft =  getFragmentManager().beginTransaction();
                ft.replace(R.id.container, ExtraFragment.newInstance());
                ft.commit();
            }
        });

        listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft =  getFragmentManager().beginTransaction();
                ft.replace(R.id.container, ListFragment.newInstance());
                ft.commit();
            }
        });

        relationshipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft =  getFragmentManager().beginTransaction();
                ft.replace(R.id.container, RelationshipFragment.newInstance());
                ft.commit();
            }
        });
    }
}

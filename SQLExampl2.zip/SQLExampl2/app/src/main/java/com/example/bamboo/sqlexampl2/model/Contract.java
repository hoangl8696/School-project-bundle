package com.example.bamboo.sqlexampl2.model;

import android.content.ContentResolver;
import android.content.UriMatcher;
import android.net.Uri;
import android.provider.BaseColumns;

public final class Contract {
    private static final String AUTHORITY = "com.example.bamboo.sqlexampl2.model.ContentProvider";
    private static final Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);
    public static final int PRESIDENT_LIST = 1;
    public static final int PRESIDENT_ID = 2;
    public static final int EXTRA_LIST = 3;
    public static final int EXTRA_ID = 4;
    public static final int RELATIONSHIP_LIST = 5;
    public static final int RELATIONSHIP_ID = 6;
    public static final int JOIN_LIST = 7;
    public static final int JOIN_ID = 8;
    public static final UriMatcher URI_MATCHER;

    static {
        URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
        URI_MATCHER.addURI(AUTHORITY, "president", PRESIDENT_LIST);
        URI_MATCHER.addURI(AUTHORITY, "president/#", PRESIDENT_ID);
        URI_MATCHER.addURI(AUTHORITY, "extra", EXTRA_LIST);
        URI_MATCHER.addURI(AUTHORITY, "extra/#", EXTRA_ID);
        URI_MATCHER.addURI(AUTHORITY, "relationship", RELATIONSHIP_LIST);
        URI_MATCHER.addURI(AUTHORITY, "relationship/#", RELATIONSHIP_ID);
        URI_MATCHER.addURI(AUTHORITY, "join", JOIN_LIST);
        URI_MATCHER.addURI(AUTHORITY, "join/#", JOIN_ID);
    }

    private Contract () {}

    public static final class President implements BaseColumns {

        private static final String PATH_NAME = "president";
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_NAME);
        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + PATH_NAME;
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + PATH_NAME;

        public static final String TABLE_NAME = "President";
        public static final String COLUMN_ID = BaseColumns._ID;
        public static final String COLUMN_NAME = "Name";
        public static final String COLUMN_YEAR = "Year";
    }

    public static final class Extra implements BaseColumns {

        private static final String PATH_NAME = "extra";
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_NAME);
        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + PATH_NAME;
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + PATH_NAME;

        public static final String TABLE_NAME = "Extra";
        public static final String COLUMN_ID = BaseColumns._ID;
        public static final String COLUMN_EXTRA = "Extra";
    }


    public static final class Relationship implements BaseColumns{

        private static final String PATH_NAME = "relationship";
        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_NAME);
        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + PATH_NAME;
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + PATH_NAME;

        public static final String TABLE_NAME = "Relationship";
        public static final String COLUMN_ID = BaseColumns._ID;
        public static final String COLUMN_ID_1 = "ID_1";
        public static final String COLUMN_ID_2 = "ID_2";
    }
}

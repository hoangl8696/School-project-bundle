package com.example.bamboo.sqlexampl2.model;


public class President {

    private String name;
    private String year;

    public President (String name, int from, int to) {
        this.name = name;
        this.year = Integer.toString(from) + " - " +Integer.toString(to);
    }

    public President (String name, String from, String to) {
        this.name = name;
        this.year = from + " - " + to;
    }

    public String getName() {
        return this.name;
    }

    public String getYear() {
        return this.year;
    }

    public void setName (String name) {
        this.name = name;
    }

    public void setYear (String from, String to) {
        this.year = from + " - " + to;
    }

    public void setYear (int from, int to) {
        this.year = Integer.toString(from) + " - " + Integer.toString(to);
    }
}

package com.example.bamboo.sqlexampl2;

import android.app.LoaderManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.bamboo.sqlexampl2.model.Contract;

public class ListFragment extends android.app.ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {
//    private static final String[] from = new String[] {Contract.President.COLUMN_NAME, Contract.President.COLUMN_YEAR};
//    private static final String[] from = new String[] {Contract.Extra.COLUMN_ID, Contract.Extra.COLUMN_EXTRA};
    private static final String[] from = new String[] {Contract.Relationship.COLUMN_ID_1, Contract.Relationship.COLUMN_ID_2};
    private static final int[] to = new int[] {android.R.id.text1, android.R.id.text2};

    private static final String[] from2 = new String[] {Contract.Extra.COLUMN_EXTRA};
    private static final int[] to2 = new int[] {android.R.id.text1};
    private SimpleCursorAdapter adapter;
    private SimpleCursorAdapter spinnerAdapter;
    private Spinner spinner;
    private long id;

    public ListFragment() {
        // Required empty public constructor
    }

    public static ListFragment newInstance() {
        ListFragment fragment = new ListFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_list, container, false);
        spinner = (Spinner) v.findViewById(R.id.spinner_3);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        adapter = new SimpleCursorAdapter(getActivity(), android.R.layout.simple_list_item_2, null, from, to, 0);
        setListAdapter(adapter);

        spinnerAdapter = new SimpleCursorAdapter(getActivity(), android.R.layout.simple_dropdown_item_1line, null, from2, to2, 0);
        spinner.setAdapter(spinnerAdapter);
        getLoaderManager().initLoader(0, null, this);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                id = adapterView.getItemIdAtPosition(i);
                Bundle bundle = new Bundle();
                bundle.putLong("id", id);
                getLoaderManager().restartLoader(1, bundle, ListFragment.this);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        String[] columns;
        switch (i) {
            case 0:
                columns = new String[] {Contract.Extra.COLUMN_ID, Contract.Extra.COLUMN_EXTRA};
                return new CursorLoader(getActivity(), Contract.Extra.CONTENT_URI, columns, null, null, null);
            case 1:
                columns = new String[] {Contract.Relationship.COLUMN_ID, Contract.Relationship.COLUMN_ID_1, Contract.Relationship.COLUMN_ID_2};
                String[] args = new String[] {Long.toString(bundle.getLong("id"))};
                return new CursorLoader(getActivity(), Contract.Relationship.CONTENT_URI, columns, Contract.Relationship.COLUMN_ID_2+ " IN(?)", args, null);
            default:
                return null;
        }

//        String[] columns = new String[] {Contract.Relationship.COLUMN_ID, Contract.Relationship.COLUMN_ID_1, Contract.Relationship.COLUMN_ID_2};
//        return new CursorLoader(getActivity(), Contract.Relationship.CONTENT_URI, columns, null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        switch (loader.getId()) {
            case 0:
                spinnerAdapter.swapCursor(cursor);
                break;
            case 1:
                adapter.swapCursor(cursor);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        switch (loader.getId()) {
            case 0:
                spinnerAdapter.swapCursor(null);
                break;
            case 1:
                adapter.swapCursor(null);
        }
    }
}

package com.example.bamboo.externalstorageview;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class MainActivity extends AppCompatActivity {
    private TextView txt;
    private String content = "", checker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.read);
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            try {
                File file = new File (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Example.txt");
                BufferedReader br = new BufferedReader(new FileReader(file));
                while ((checker = br.readLine()) != null) {
                    content += checker+"\n";
                }
                txt.setText(content);
                br.close();
            } catch (Exception e) {

            }
        }
    }
}

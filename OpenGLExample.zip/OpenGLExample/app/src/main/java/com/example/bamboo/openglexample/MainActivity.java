package com.example.bamboo.openglexample;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import static com.example.bamboo.openglexample.MainActivity.ExtendRenderer.loadShader;

public class MainActivity extends AppCompatActivity {

    private GLSurfaceView mSurfaceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSurfaceView = new ExtendSurfaceView(this);
        setContentView(mSurfaceView);
    }

    public class ExtendSurfaceView  extends GLSurfaceView {

        private final ExtendRenderer mExtendRenderer;

        public ExtendSurfaceView(Context context) {
            super(context);
            setEGLContextClientVersion(2);
            mExtendRenderer = new ExtendRenderer();
            setRenderer(mExtendRenderer);
        }
    }

    public static class ExtendRenderer implements GLSurfaceView.Renderer {

//        private Triangle mTriangle;
        private Square mSquare;
        private final float[] mMVPMatrix = new float[16];
        private final float[] mProjectionMatrix = new float[16];
        private final float[] mViewMatrix = new float[16];
        @Override
        public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
            GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
//            mTriangle = new Triangle();
            mSquare = new Square();
//            GLES20.glEnable(GLES20.GL_CULL_FACE);
//            GLES20.glCullFace(GLES20.GL_BACK);
        }

        @Override
        public void onSurfaceChanged(GL10 gl10, int width, int height) {
            GLES20.glViewport(0,0, width, height);
            float ratio = (float) width/height;
            Matrix.frustumM(mProjectionMatrix, 0, -ratio, ratio, -1,1,3,7);
        }

        @Override
        public void onDrawFrame(GL10 gl10) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            Matrix.setLookAtM(mViewMatrix, 0,0,0,3,0f,0f,0f,0f,1.0f,0.0f);
            Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);
            mSquare.draw(mMVPMatrix);
        }

        public static int loadShader (int type, String shaderCode) {
            int shader = GLES20.glCreateShader(type);
            GLES20.glShaderSource(shader, shaderCode);
            GLES20.glCompileShader(shader);
            return shader;
        }
    }
//    public static class Triangle {
//        private final String vertexShaderCode =
//                // This matrix member variable provides a hook to manipulate
//                // the coordinates of the objects that use this vertex shader
//                "uniform mat4 uMVPMatrix;" +
//                        "attribute vec4 vPosition;" +
//                        "void main() {" +
//                        // the matrix must be included as a modifier of gl_Position
//                        // Note that the uMVPMatrix factor *must be first* in order
//                        // for the matrix multiplication product to be correct.
//                        "  gl_Position = uMVPMatrix * vPosition;" +
//                        "}";
//        private final String fragmentShaderCode =
//                "precision mediump float;" +
//                        "uniform vec4 vColor;" +
//                        "void main() {" +
//                        "  gl_FragColor = vColor;" +
//                        "}";
//        private final FloatBuffer vertexBuffer;
//        private final int mProgram;
//        private int mPositionHandle;
//        private int mColorHandle;
//        private int mMVPMatrixHandle;
//        // number of coordinates per vertex in this array
//        static final int COORDS_PER_VERTEX = 3;
//        float triangleCoords[] = {
//                // in counterclockwise order:
//                0.0f,  0.622008459f, 0.0f,   // top
//                -0.25f, -0.311004243f, 0.0f,   // bottom left
//                0.5f, -0.311004243f, 0.0f    // bottom right
//        };
//        private final int vertexCount = triangleCoords.length / COORDS_PER_VERTEX;
//        private final int vertexStride = COORDS_PER_VERTEX * 4; // 4 bytes per vertex
//        float color[] = { 0.63671875f, 0.76953125f, 0.22265625f, 0.0f };
//        /**
//         * Sets up the drawing object data for use in an OpenGL ES context.
//         */
//        public Triangle() {
//            // initialize vertex byte buffer for shape coordinates
//            ByteBuffer bb = ByteBuffer.allocateDirect(
//                    // (number of coordinate values * 4 bytes per float)
//                    triangleCoords.length * 4);
//            // use the device hardware's native byte order
//            bb.order(ByteOrder.nativeOrder());
//            // create a floating point buffer from the ByteBuffer
//            vertexBuffer = bb.asFloatBuffer();
//            // add the coordinates to the FloatBuffer
//            vertexBuffer.put(triangleCoords);
//            // set the buffer to read the first coordinate
//            vertexBuffer.position(0);
//            // prepare shaders and OpenGL program
//            int vertexShader = loadShader(
//                    GLES20.GL_VERTEX_SHADER, vertexShaderCode);
//            int fragmentShader = loadShader(
//                    GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
//            mProgram = GLES20.glCreateProgram();             // create empty OpenGL Program
//            GLES20.glAttachShader(mProgram, vertexShader);   // add the vertex shader to program
//            GLES20.glAttachShader(mProgram, fragmentShader); // add the fragment shader to program
//            GLES20.glLinkProgram(mProgram);                  // create OpenGL program executables
//        }
//        /**
//         * Encapsulates the OpenGL ES instructions for drawing this shape.
//         *
//         * @param mvpMatrix - The Model View Project matrix in which to draw
//         * this shape.
//         */
//        public void draw(float[] mvpMatrix) {
//            // Add program to OpenGL environment
//            GLES20.glUseProgram(mProgram);
//            // get handle to vertex shader's vPosition member
//            mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
//            // Enable a handle to the triangle vertices
//            GLES20.glEnableVertexAttribArray(mPositionHandle);
//            // Prepare the triangle coordinate data
//            GLES20.glVertexAttribPointer(
//                    mPositionHandle, COORDS_PER_VERTEX,
//                    GLES20.GL_FLOAT, false,
//                    vertexStride, vertexBuffer);
//            // get handle to fragment shader's vColor member
//            mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
//            // Set color for drawing the triangle
//            GLES20.glUniform4fv(mColorHandle, 1, color, 0);
//            // get handle to shape's transformation matrix
//            mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
////            MyGLRenderer.checkGlError("glGetUniformLocation");
//            // Apply the projection and view transformation
//            GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
////            MyGLRenderer.checkGlError("glUniformMatrix4fv");
//            // Draw the triangle
//            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
//            // Disable vertex array
//            GLES20.glDisableVertexAttribArray(mPositionHandle);
//        }
//    }
//    public static class Triangle {
//        private FloatBuffer mVertextBuffer;
//        private final int mProgram;
//        private int mPositionHandle;
//        private int mColorHandle;
//        private int mMVPMatrixHandle;
//        private final String mVerTextShaderCode =
//                "attribute vec4 vPosition;"
//                        + "uniform mat4 uMVPMatrix;"
//                        + "void main() {"
//                        + "   gl_Position = uMVPMatrix * vPosition;"
//                        + "}";
//
//        private final String mFragmentShaderCode =
//                "precision mediump float;"
//                        + "uniform vec4 vColor;"
//                        + "void main() {"
//                        + "    gl_FragColor = vColor;"
//                        + "}";
//
//        static final int COORDS_PER_VERTEX = 3;
//
//        float[] mTriangleCoords = {
//                0.0f,  0.622008459f, 0.0f,
//                -0.5f, -0.311004243f, 0.0f,
//                0.5f, -0.311004243f, 0.0f
//        };
//
//        float[] mColor = {0.63671875f, 0.76953125f, 0.22265625f, 1.0f};
//
//        private final int vertexCount = mTriangleCoords.length / COORDS_PER_VERTEX;
//        private final int vertexStride = COORDS_PER_VERTEX * 4;
//        public Triangle() {
//            ByteBuffer bb = ByteBuffer.allocateDirect(mTriangleCoords.length * 4);
//            bb.order(ByteOrder.nativeOrder());
//            mVertextBuffer = bb.asFloatBuffer();
//            mVertextBuffer.put(mTriangleCoords);
//            mVertextBuffer.position(0);
//
//            int verTexShader = loadShader(GLES20.GL_VERTEX_SHADER, mVerTextShaderCode);
//            int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, mFragmentShaderCode);
//            mProgram = GLES20.glCreateProgram();
//            GLES20.glAttachShader(mProgram, verTexShader);
//            GLES20.glAttachShader(mProgram, fragmentShader);
//            GLES20.glLinkProgram(mProgram);
//        }
//
//        public void draw(float[] mvpMatrix) {
//            GLES20.glUseProgram(mProgram);
//
//            mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
//            GLES20.glEnableVertexAttribArray(mPositionHandle);
//            GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, mVertextBuffer);
//
//            mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
//            mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
//            GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
//            GLES20.glUniform4fv(mColorHandle, 1, mColor, 0);
//            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0 , vertexCount);
//            GLES20.glDisableVertexAttribArray(mPositionHandle);
//        }
//    }


    public static class Square {
        private FloatBuffer mVertexBuffer;
        private ShortBuffer mDrawBuffer;
        private int mProgram;
        static final int COORDS_PER_VERTEX = 3;
        private int mPositionHandle;
        private int mColorHandle;
        private int mMVPMatrixHandle;

        float mSquareCoords[] = {
                -0.25f,  0f, 0.0f,
                0f, -0.25f, 0.0f,
                0.25f, 0f, 0.0f,
                0f,  0.25f, 0.0f
        };

        private short mDrawOrder[] = {0,1,2,0,2,3};
        float[] mColor = {0.63671875f, 0.76953125f, 0.22265625f, 1.0f};

        private final String mVerTextShaderCode =
                "attribute vec4 vPosition;"
                        + "uniform mat4 uMVPMatrix;"
                        + "void main() {"
                        + "   gl_Position = uMVPMatrix * vPosition;"
                        + "}";

        private final String mFragmentShaderCode =
                "precision mediump float;"
                        + "uniform vec4 vColor;"
                        + "void main() {"
                        + "    gl_FragColor = vColor;"
                        + "}";

        private final int vertexStride = COORDS_PER_VERTEX * 4;

        public Square() {
            ByteBuffer bb1 = ByteBuffer.allocateDirect(mSquareCoords.length * 4);
            bb1.order(ByteOrder.nativeOrder());
            mVertexBuffer = bb1.asFloatBuffer();
            mVertexBuffer.put(mSquareCoords);
            mVertexBuffer.position(0);


            ByteBuffer bb2 = ByteBuffer.allocateDirect(mDrawOrder.length * 2);
            bb2.order(ByteOrder.nativeOrder());
            mDrawBuffer = bb2.asShortBuffer();
            mDrawBuffer.put(mDrawOrder);
            mDrawBuffer.position(0);

            int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, mVerTextShaderCode);
            int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, mFragmentShaderCode);

            mProgram = GLES20.glCreateProgram();
            GLES20.glAttachShader(mProgram, vertexShader);
            GLES20.glAttachShader(mProgram, fragmentShader);
            GLES20.glLinkProgram(mProgram);
        }
        public void draw(float[] mvpMatrix) {
            GLES20.glUseProgram(mProgram);

            mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
            GLES20.glEnableVertexAttribArray(mPositionHandle);
            GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX, GLES20.GL_FLOAT, false, vertexStride, mVertexBuffer);

            mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
            mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
            GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
            GLES20.glUniform4fv(mColorHandle, 1, mColor, 0);

            GLES20.glDrawElements(GLES20.GL_TRIANGLES, mDrawOrder.length, GLES20.GL_UNSIGNED_SHORT, mDrawBuffer);
            GLES20.glDisableVertexAttribArray(mPositionHandle);
        }
    }
}

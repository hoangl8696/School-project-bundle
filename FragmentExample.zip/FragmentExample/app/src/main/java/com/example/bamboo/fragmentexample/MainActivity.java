package com.example.bamboo.fragmentexample;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ListFragment.OnFragmentInteractionListener {

    private static String[] presidentsList = {
            "Stahlberg, Kaarlo Juho 1919 - 1925",
            "Relander, Lauri Kristan 1925 - 1931",
            "Svinhufvud, Pehr Evind 1931 - 1937",
            "Kallio, Kyosti 1937 - 1940",
            "Ryti, Risto Heikki 1940, 1944",
            "Mannerheim, Carl Gustav Emil 1944 - 1946",
            "Paasikivi, Juho Kusti 1946 - 1956",
            "Kekkonen, Urho Kaleva 1956 - 1982",
            "Koivisto, Mauno Henrik 1982 - 1994",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Ahtisaari, Martti Oiva Kalevi 1994 - 2000",
            "Halonen, Tarja Kaarina 2000 - 2012"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ListFragment listFragment = new ListFragment();
        Bundle bundle = new Bundle();
        bundle.putStringArray("list", presidentsList);
        listFragment.setArguments(bundle);
        ft.replace(R.id.fragContainer, listFragment);
        ft.commit();
    }

    @Override
    public void onListItemClicked(int position) {
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        DetailFragment detailFragment = new DetailFragment();
        Bundle bundle = new Bundle();
        bundle.putString("item", presidentsList[position]);
        detailFragment.setArguments(bundle);
        ft.replace(R.id.fragContainer, detailFragment);
        ft.addToBackStack(null);
        ft.commit();
    }
}

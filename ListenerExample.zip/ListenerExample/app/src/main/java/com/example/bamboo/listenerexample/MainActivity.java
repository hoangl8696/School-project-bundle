package com.example.bamboo.listenerexample;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import static android.content.res.Configuration.ORIENTATION_LANDSCAPE;

public class MainActivity extends AppCompatActivity /*METHOD 3: Implement Interface*/ implements View.OnClickListener {
    private Button btn;
    private TextView textView;
    private TextView numView;
    private ImageButton imgBtn;

    private float dX;
    private float dY;
    private int lastAction;
    private int counter;

    /*METHOD 1: Inner class
    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (textView.getText().equals(getResources().getString(R.string.hello_world_text))){
                textView.setText(R.string.hello_world_text_change);
            } else {
                textView.setText(R.string.hello_world_text);
            }
        }
    };*/

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("currentLabel", textView.getText().toString());
        outState.putString("currentNum", numView.getText().toString());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.button);
        textView = (TextView) findViewById(R.id.textView2);
        imgBtn = (ImageButton) findViewById(R.id.imageButton);
        numView = (TextView) findViewById(R.id.textView);

        imgBtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = view.getX() - motionEvent.getRawX();
                        dY = view.getY() - motionEvent.getRawY();
                        lastAction = MotionEvent.ACTION_DOWN;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        view.setY(motionEvent.getRawY() + dY);
                        view.setX(motionEvent.getRawX() + dX);
                        //lastAction = MotionEvent.ACTION_MOVE;
                        break;

                    case MotionEvent.ACTION_UP:
                        if (lastAction == MotionEvent.ACTION_DOWN) {
                            counter = Integer.parseInt(numView.getText().toString());
                            counter = counter + 1;
                            numView.setText(Integer.toString(counter));
                        }
                        break;

                    default:
                        return false;
                }
                return true;
            }
        });
        /*METHOD 1: Inner class
        btn.setOnClickListener(clickListener);*/

        /*METHOD 2: Anonymous class
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (textView.getText().equals(getResources().getString(R.string.hello_world_text))){
                    textView.setText(R.string.hello_world_text_change);
                } else {
                    textView.setText(R.string.hello_world_text);
                }
            }
        });*/

        if (savedInstanceState != null) {
            textView.setText(savedInstanceState.getString("currentLabel"));
            numView.setText(savedInstanceState.getString("currentNum"));
        }

        //METHOD 3: Implement Interface
        btn.setOnClickListener(this);
    }
    //METHOD 3: Implement Interface
    @Override
    public void onClick(View view) {
        if (textView.getText().equals(getResources().getString(R.string.hello_world_text))){
            textView.setText(R.string.hello_world_text_change);
        } else {
            textView.setText(R.string.hello_world_text);
        }
    }
}

package com.example.bamboo.multithreadingexample;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    private TextView text;
    private Button btn;
    private ImageView img;
    private Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    text.setText((String)msg.obj);
                    break;
                default:
                    throw new IllegalArgumentException("No message with id found");
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (TextView) findViewById(R.id.text);
        btn = (Button) findViewById(R.id.button);
        img = (ImageView) findViewById(R.id.img);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RetrieveData retrieveData = new RetrieveData(handler);
                Thread t = new Thread(retrieveData);
                t.start();
                try {
                    URL url = new URL("http://users.metropolia.fi/~hoangl/UglyMe.jpg");
                    RetrieveImg getImg = new RetrieveImg();
                    getImg.execute(url);
                } catch (Exception e) {

                }

            }
        });
    }

    public class RetrieveImg extends AsyncTask<URL, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(URL... urls) {
            try {
                URL url = urls[0];
                URLConnection connection = url.openConnection();
                Bitmap map = BitmapFactory.decodeStream(connection.getInputStream());
                return map;
            } catch (Exception e) {

            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            img.setImageBitmap(bitmap);
        }
    }

    public class RetrieveData implements Runnable {

        private Handler handler;
        private String result;

        public RetrieveData (Handler handler) {
            this.handler = handler;
            result = "";
        }

        @Override
        public void run() {
            try {
                URL url = new URL("http://users.metropolia.fi/~hoangl/Example.txt");
                URLConnection connection = url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                String container;
                while ((container = reader.readLine()) != null) {
                    result += container;
                }
                reader.close();

                Message msg = handler.obtainMessage();
                Log.d("result", result);
                msg.obj = result;
                msg.what = 0;
                handler.sendMessage(msg);
            } catch (Exception e) {

            }
        }
    }
}

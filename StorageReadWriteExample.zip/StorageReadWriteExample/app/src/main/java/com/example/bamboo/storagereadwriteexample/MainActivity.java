package com.example.bamboo.storagereadwriteexample;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.Notification;
import android.app.NotificationManager;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.NotificationCompat;
import android.view.View;
import android.widget.Button;
import android.widget.RemoteViews;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements BlankFragment.OnFragmentInteractionListener, ReadFragment.OnFragmentInteractionListener {

    private Button wrtBtn;
    private Button rdBtn;
    private static final String FILE_NAME = "Example.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wrtBtn = (Button) findViewById(R.id.write_btn);
        rdBtn = (Button) findViewById(R.id.read_btn);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.container, BlankFragment.newInstance(FILE_NAME));
        ft.commit();
        wrtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container, BlankFragment.newInstance(FILE_NAME));
                ft.commit();
            }
        });
        rdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.container, ReadFragment.newInstance(FILE_NAME));
                ft.commit();
            }
        });
    }

    private RemoteViews getCusomNotificationView (){
        RemoteViews view = new RemoteViews(getPackageName(), R.layout.custom_notification);
        view.setImageViewResource(R.id.imagenotileft, R.drawable.ic_sucessful);
        view.setTextViewText(R.id.noti_text, "Hooray");
        view.setTextViewText(R.id.noti_title, "Sucess!");
        return view;
    }
    @Override
    public void onButtonPressed(boolean isOk) {
        if (isOk) {
            android.support.v4.app.NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this)
                    .setSmallIcon(R.drawable.ic_sucessful)
                    .setAutoCancel(true)
                    .setTicker("Heeyyooo!")
                    .setContent(getCusomNotificationView());
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification notification = builder.build();
            notificationManager.notify(1, notification);

            Toast.makeText(this, "Data sent", Toast.LENGTH_SHORT).show();
            final Snackbar snackbar = Snackbar.make(findViewById(R.id.notification_container),"Data sent", Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            snackbar.show();
        } else {
            Toast.makeText(this, "Error: Something went wrong", Toast.LENGTH_SHORT).show();
            final Snackbar snackbar = Snackbar.make(findViewById(R.id.notification_container),"Error, please retry", Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction("Retry", new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
            snackbar.show();
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}

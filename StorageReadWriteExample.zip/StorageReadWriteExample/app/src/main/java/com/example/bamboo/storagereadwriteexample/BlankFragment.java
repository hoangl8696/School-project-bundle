package com.example.bamboo.storagereadwriteexample;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class BlankFragment extends android.app.Fragment {

    private OnFragmentInteractionListener activity;
    private EditText text;
    private Button btn;
    private Button btn2;

    public BlankFragment() {
        // Required empty public constructor
    }

    public static BlankFragment newInstance(String filename) {
        BlankFragment fragment = new BlankFragment();
        Bundle bundle = new Bundle();
        bundle.putString("filename", filename);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_blank, container, false);
        text = (EditText) v.findViewById(R.id.editText);
        btn = (Button) v.findViewById(R.id.button);
        btn2 = (Button) v.findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String state = Environment.getExternalStorageState();
                if (Environment.MEDIA_MOUNTED.equals(state)){
                    try {
                        //External writing
                        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), getArguments().getString("filename"));
                        BufferedWriter br = new BufferedWriter(new FileWriter(file, true));
                        br.write(" "+text.getText().toString());
                        br.flush();
                        br.close();
                        activity.onButtonPressed(true);
                        text.getText().clear();
                        PackageManager packageManager = getActivity().getPackageManager();
                        try {
                            Intent i = packageManager.getLaunchIntentForPackage("com.example.bamboo.externalstorageview");
                            i.addCategory(Intent.CATEGORY_LAUNCHER);
                            getActivity().startActivity(i);
                        } catch (Exception e){

                    }
                } catch (Exception e) {
                    activity.onButtonPressed(false);
                    }
                }
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Save file in internal storage
                try {
                    BufferedWriter bf = new BufferedWriter(new OutputStreamWriter(getActivity().openFileOutput(getArguments().getString("filename"), Context.MODE_APPEND)));
                    bf.write(" "+text.getText().toString());
                    bf.flush();
                    bf.close();
                    activity.onButtonPressed(true);
                    text.getText().clear();
                } catch (Exception e) {
                    activity.onButtonPressed(false);
                }
            }
        });
        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            activity = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        activity = null;
    }

    public interface OnFragmentInteractionListener {
        void onButtonPressed(boolean isOk);
    }
}

package com.example.bamboo.storagereadwriteexample;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReadFragment extends android.app.Fragment{

    private OnFragmentInteractionListener mListener;
    private TextView text;
    private String readedText;

    public ReadFragment() {
        // Required empty public constructor
    }

    public static ReadFragment newInstance(String filename) {
        ReadFragment fragment = new ReadFragment();
        Bundle bundle = new Bundle();
        bundle.putString("filename", filename);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_read, container, false);
        text = (TextView) v.findViewById(R.id.read);
        try {
            int content;
            //Internal storage
            BufferedReader br = new BufferedReader(new InputStreamReader(getActivity().openFileInput(getArguments().getString("filename"))));
            readedText = "";
            while ((content = br.read()) != -1) {
                readedText = readedText + (char) content;
            }
            text.setText(readedText);
            br.close();
        } catch (Exception e) {

        }
        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}

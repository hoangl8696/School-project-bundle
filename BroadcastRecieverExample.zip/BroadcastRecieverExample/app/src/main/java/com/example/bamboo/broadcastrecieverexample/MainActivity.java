package com.example.bamboo.broadcastrecieverexample;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private BroadcastReceiver mReceiver;
    private BroadcastReceiver mCustomReciever;
    private IntentFilter mFilter;
    private boolean mIsRegistered = false;

    private TextView mBatteryFullText;
    private TextView mBatteryChargeStateText;
    private TextView mBatteryLevelText;
    private Button mButton;

    private static final String MY_CUSTOM_INTENT = "com.example.bamboo.broadcastrecieverexample.CUSTOM_INTENT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFilter= new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        mReceiver = new BatteryMonitoringBR();
        mCustomReciever = new CustomBR();

        mBatteryFullText = (TextView) findViewById(R.id.battery_full_data);
        mBatteryChargeStateText = (TextView) findViewById(R.id.battery_charge_state_data);
        mBatteryLevelText = (TextView) findViewById(R.id.battery_level_data);
        mButton = (Button) findViewById(R.id.button);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(MY_CUSTOM_INTENT);
                sendBroadcast(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!mIsRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(MY_CUSTOM_INTENT);
            this.registerReceiver(mReceiver, mFilter);
            this.registerReceiver(mCustomReciever, filter);
            mIsRegistered= true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mIsRegistered) {
            this.unregisterReceiver(mReceiver);
            this.unregisterReceiver(mCustomReciever);
            mIsRegistered= false;
        }
    }

    public void updateUI (int chargeStatus, int plugStatus, float percentageStatus) {
        switch (chargeStatus) {
            case BatteryManager.BATTERY_STATUS_CHARGING:
                mBatteryFullText.setText("False");
                break;
            case BatteryManager.BATTERY_STATUS_FULL:
                mBatteryFullText.setText("True");
                break;
        }
        switch (plugStatus) {
            case BatteryManager.BATTERY_PLUGGED_USB:
                mBatteryChargeStateText.setText("USB");
                break;
            case BatteryManager.BATTERY_PLUGGED_AC:
                mBatteryChargeStateText.setText("AC");
                break;
            default:
                mBatteryChargeStateText.setText("Unplugged");
        }
        mBatteryLevelText.setText(Float.toString(percentageStatus) + "%");
    }

    private class BatteryMonitoringBR extends BroadcastReceiver {
        private int mStatus;
        private int mPlugStatus;
        private float mBatteryPct;

        @Override
        public void onReceive(Context context, Intent intent) {
            mStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            mPlugStatus = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            mBatteryPct = level / (float)scale * 100;
            updateUI (mStatus, mPlugStatus, mBatteryPct);
        }
    }

    private class CustomBR extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(MainActivity.this, "This is a custom intent broadcasting", Toast.LENGTH_SHORT).show();
        }
    }
}

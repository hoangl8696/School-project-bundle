package com.example.bamboo.httpretrofit2example.server;

/**
* https://code.tutsplus.com/tutorials/sending-data-with-retrofit-2-http-client-for-android--cms-27845
* */

public class ApiUtils {
    public static final String BASE_URL = "http://users.metropolia.fi/";

    public static ServerAPI getServerAPI () {
        return RetrofitClient.getClients(BASE_URL).create(ServerAPI.class);
    }
}

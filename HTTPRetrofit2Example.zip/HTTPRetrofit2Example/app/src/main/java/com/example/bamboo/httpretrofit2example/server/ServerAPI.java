package com.example.bamboo.httpretrofit2example.server;

import com.example.bamboo.httpretrofit2example.models.Example;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ServerAPI {
    @GET("/~hoangl/colors.txt")
    Call<Example> getJSON();
}

package com.example.bamboo.httpretrofit2example.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/********
 * Model taken from http://www.jsonschema2pojo.org/
 *********/

public class Code {

    @SerializedName("rgba")
    @Expose
    private List<Integer> rgba = null;
    @SerializedName("hex")
    @Expose
    private String hex;

    public List<Integer> getRgba() {
        return rgba;
    }

    public void setRgba(List<Integer> rgba) {
        this.rgba = rgba;
    }

    public String getHex() {
        return hex;
    }

    public void setHex(String hex) {
        this.hex = hex;
    }

}

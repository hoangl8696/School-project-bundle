package com.example.bamboo.httpretrofit2example.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/********
 * Model taken from http://www.jsonschema2pojo.org/
 *********/

public class Example {

    @SerializedName("colors")
    @Expose
    private List<Color> colors = null;

    public List<Color> getColors() {
        return colors;
    }

    public void setColors(List<Color> colors) {
        this.colors = colors;
    }

}
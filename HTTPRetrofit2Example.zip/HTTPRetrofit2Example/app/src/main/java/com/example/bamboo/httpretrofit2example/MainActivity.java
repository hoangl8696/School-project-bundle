package com.example.bamboo.httpretrofit2example;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.bamboo.httpretrofit2example.models.Color;
import com.example.bamboo.httpretrofit2example.models.Example;
import com.example.bamboo.httpretrofit2example.server.ApiUtils;
import com.example.bamboo.httpretrofit2example.server.ServerAPI;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
* https://developer.android.com/training/material/lists-cards.html
* */

public class MainActivity extends AppCompatActivity {

    private ServerAPI mAPI;
    private RecyclerView mRecyclerView;
    private AnswerAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAPI = ApiUtils.getServerAPI();

        mRecyclerView = (RecyclerView) findViewById(R.id.rv_answers);
        mAdapter = new AnswerAdapter (new ArrayList<Color>());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);

        getContent();
    }

    private void getContent() {
        mAPI.getJSON().enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                if (response.isSuccessful()) {
                    mAdapter.updateAnswer(response.body().getColors());
                } else {
                    int status = response.code();
                    Toast.makeText(MainActivity.this, "status: "+status, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error loading from API", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class AnswerAdapter extends RecyclerView.Adapter<AnswerAdapter.ViewHolder> {
        private List<Color> mItems;

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView txtcategory, txttype, txtcode;

            public ViewHolder(View itemView) {
                super(itemView);
                txtcategory = (TextView) itemView.findViewById(R.id.txtcategory);
                txttype = (TextView) itemView.findViewById(R.id.txttype);
                txtcode = (TextView) itemView.findViewById(R.id.txtcode);
            }
        }

        public AnswerAdapter(List<Color> colors) {
            mItems = colors;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);
            View colorView = inflater.inflate(R.layout.rows, parent, false);
            ViewHolder holder = new ViewHolder(colorView);
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Color item = mItems.get(position);
            TextView category = holder.txtcategory;
            category.setText(item.getCategory());
            TextView type = holder.txttype;
            type.setText(item.getType());
            TextView code = holder.txtcode;
            code.setText(item.getCode().getHex());
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }

        public void updateAnswer(List<Color> colors) {
            mItems = colors;
            notifyDataSetChanged();
        }
    }
}
